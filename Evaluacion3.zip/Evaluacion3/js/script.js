function validar(){
    var val_user = validar_usuario();
    var val_contra = validar_pass();
    var val_contra2 = validar_pass2();
    var val_direccion=validar_direccion();
    var val_telef = validar_telefono();
    return val_user && val_contra && val_contra2 && val_direccion && val_telef; 
}

function enviar(){
    if(validar()) {
    }
}

//validar usuario
function validar_usuario() {
    var user = document.getElementById("usuario").value;
    var div = document.getElementById("error_user");
    var arroba = user.indexOf("@");
    var punto = user.lastIndexOf(".");
    if (arroba < 1) {
        div.innerText = "Usuario invalido (revise si contiene @";
        div.className = "text-danger";
        return false;
    } else {
        if (arroba < 2) {
            div.innerText = "El nombre de usuario del correo no es válido";
            div.className = "text-danger";
            return false;
        } else {
            if (arroba + 3 > punto || punto + 1 >= email.length - 1 ) {
                div.innerText = "El usuario no es válido";
                div.className = "text-danger";
                return false;
            } else {
                div.innerText = "";
                return true;
            }
        }
    }
}

//validar contraseña
function validar_pass() {
    var contraseña = document.getElementById("pass").value;
    var div = document.getElementById("error_pass");

    if (contraseña.length >= 3 && contraseña.length <= 6) {
        div.innerText = "";
        return true;

    } else if(contraseña == ""){
        div.innerText= "Debes ingresar una contraseña";
        div.className= "text-danger";
        return false;

    } else {
        div.innerText = "La contraseña debe tener entre 3 y 6 caracteres";
        div.className = "text-danger";
        return false;
    }
}

function validar_pass2() {
    var contraseña = document.getElementById("pass").value;
    var confirmar = document.getElementById("pass2").value;
    var div = document.getElementById("error_pass2");

    if (confirmar.length >= 3 && confirmar.length <= 6 && confirmar === contraseña) {
        div.innerText = "";
        return true;
    
    }else if (confirmar == "") {
        div.innerText= "Debes ingresar nuevamente su contraseña";
        div.className= "text-danger";
        return false;
    
    } else {
        div.innerText = "La confirmación de la contraseña debe coincidir con la contraseña ya establecida";
        div.className = "text-danger";
        return false;
    }
}

//validar direccion
function validar_direccion(){
    var direccion= document.getElementById("direccion").value;
    var div= document.getElementById("error_direcc");
    
    if (direccion == ""){
        div.innerText= "Debes ingresar una direccion";
        div.className= "text-danger";
     
    }
}

//validar telefono
function validar_telefono() {
    var telefono = document.getElementById("telefono").value;
    var div = document.getElementById("error_telef");

    if (telefono.length >= 9 && telefono.length == +569) {
        div.innerText = "";
        return true;
    } else if (telefono == ""){
        div.innerText= "Debes ingresar un numero telefonico";
        div.className= "text-danger";
        return false;

    
    } else {
        div.innerText = "El número telefónico debe tener 9 numeros";
        div.className = "text-danger";
        return false;
    }
}
